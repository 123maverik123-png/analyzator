# license.py — работа с лицензией (демо, активация, проверка)
import os
import sys
import json
import requests
from datetime import datetime, timedelta
from config import CENTRAL_URL, MACHINE_ID, BASE_DIR

# Кэш всегда рядом с EXE / скриптом (BASE_DIR из config.py корректно
# обрабатывает и frozen-сборку, и обычный запуск)
LICENSE_FILE   = os.path.join(BASE_DIR, "license_cache.json")
LICENSE_SERVER = CENTRAL_URL

# Сколько дней после истечения кэша разрешаем работать без связи с сервером
GRACE_DAYS = 3


def _load_cache():
    if os.path.exists(LICENSE_FILE):
        try:
            with open(LICENSE_FILE, "r", encoding="utf-8") as f:
                return json.load(f)
        except Exception:
            pass
    return {}


def _save_cache(data):
    try:
        with open(LICENSE_FILE, "w", encoding="utf-8") as f:
            json.dump(data, f, indent=2)
    except Exception:
        pass


def _request(endpoint, data):
    """Делает POST-запрос к серверу лицензирования.
    Возвращает dict с полем 'status'. При любой сетевой ошибке
    возвращает {"status": "unreachable"} — отдельный статус,
    чтобы отличать «сервер ответил ошибкой» от «сервер недоступен».
    """
    if not LICENSE_SERVER:
        return {"status": "unreachable", "detail": "CENTRAL_URL не задан"}
    url = f"{LICENSE_SERVER}{endpoint}"
    try:
        resp = requests.post(url, json=data, timeout=5)
        if resp.status_code == 200:
            return resp.json()
        return {"status": "error", "detail": resp.text}
    except requests.exceptions.ConnectionError:
        return {"status": "unreachable", "detail": "Нет соединения"}
    except requests.exceptions.Timeout:
        return {"status": "unreachable", "detail": "Таймаут соединения"}
    except Exception as e:
        return {"status": "unreachable", "detail": str(e)}


def _cache_valid(cache):
    """Кэш считается действующим, если статус trial/active и дата не истекла."""
    if cache.get("status") not in ("trial", "active"):
        return False
    end_date = cache.get("end_date")
    if not end_date:
        return False
    return datetime.now().isoformat() < end_date


def _cache_in_grace(cache):
    """Кэш в grace period: статус был trial/active, но истёк не более GRACE_DAYS назад.
    Позволяет работать при временной недоступности сервера.
    """
    if cache.get("status") not in ("trial", "active"):
        return False
    end_date = cache.get("end_date")
    if not end_date:
        return False
    end = datetime.fromisoformat(end_date)
    grace_limit = end + timedelta(days=GRACE_DAYS)
    return datetime.now() < grace_limit


def get_license_status():
    """Возвращает: 'trial', 'active', 'expired', 'error'.

    Логика:
    1. Кэш действует → вернуть статус из кэша (без сети).
    2. Кэш просрочен → идти на сервер.
       а. Сервер ответил → обновить кэш, вернуть статус.
       б. Сервер недоступен + кэш в grace period → пустить, вернуть статус кэша.
       в. Сервер недоступен + нет grace → вернуть 'error'.
    3. Кэша нет → регистрация trial или ошибка.
    """
    cache = _load_cache()

    # 1. Действующий кэш — не идём в сеть
    if _cache_valid(cache):
        return cache["status"]

    # 2. Нет сервера — проверить grace period
    if not LICENSE_SERVER:
        if _cache_in_grace(cache):
            return cache["status"]
        return "error"

    # Идём на сервер
    result = _request("/license/verify", {"device_id": MACHINE_ID})

    if result["status"] == "unreachable":
        # Сервер недоступен
        if _cache_in_grace(cache):
            return cache["status"]   # работаем в grace period
        if cache.get("status") == "expired":
            return "expired"
        return "error"

    if result["status"] == "not_found":
        # Новое устройство — регистрируем trial
        trial = _request("/license/trial", {"device_id": MACHINE_ID})
        if trial["status"] in ("trial", "active"):
            _save_cache({"status": trial["status"], "end_date": trial.get("end_date")})
            return trial["status"]
        if trial["status"] == "unreachable":
            return "error"
        return "error"

    if result["status"] in ("trial", "active"):
        _save_cache({"status": result["status"], "end_date": result.get("end_date")})
        return result["status"]

    if result["status"] == "expired":
        _save_cache({"status": "expired", "end_date": cache.get("end_date")})
        return "expired"

    return "error"


def activate_license(license_key):
    result = _request("/license/activate", {"device_id": MACHINE_ID, "license_key": license_key})
    if result.get("status") == "active":
        _save_cache({"status": "active", "end_date": result.get("end_date")})
        return True, "Подписка активирована до " + result.get("end_date", "—")
    if result.get("status") == "unreachable":
        return False, "Сервер лицензирования недоступен. Проверьте интернет-соединение."
    return False, result.get("detail", "Ошибка активации")


def days_remaining():
    cache = _load_cache()
    end_date_str = cache.get("end_date")
    if not end_date_str:
        return 0
    try:
        end = datetime.fromisoformat(end_date_str)
        delta = end - datetime.now()
        return max(0, delta.days)
    except ValueError:
        return 0
