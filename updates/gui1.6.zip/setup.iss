;-- Скрипт Inno Setup для "Анализатор разговоров" --
#define MyAppName "Анализатор разговоров"
#define MyAppVersion "1.5"
#define MyAppPublisher "Ivan Duplaykov"
#define MyAppURL "123maverik123@gmail.com"
#define MyAppExeName "gui.exe"

[Setup]
AppId={{7C21B632-E0A7-48FA-8402-06DFF8611223}
AppName={#MyAppName}
AppVersion={#MyAppVersion}
AppPublisher={#MyAppPublisher}
AppPublisherURL={#MyAppURL}
AppSupportURL={#MyAppURL}
AppUpdatesURL={#MyAppURL}
DefaultDirName={localappdata}\MyCallAnalyzer
DefaultGroupName={#MyAppName}
UninstallDisplayIcon={app}\{#MyAppExeName}
ArchitecturesAllowed=x64compatible
ArchitecturesInstallIn64BitMode=x64compatible
DisableProgramGroupPage=yes
PrivilegesRequired=admin
OutputBaseFilename=MyCallAnalyzerSetup
SolidCompression=yes
WizardStyle=modern

[Languages]
Name: "russian"; MessagesFile: "compiler:Languages\Russian.isl"

[Tasks]
Name: "desktopicon"; Description: "{cm:CreateDesktopIcon}"; GroupDescription: "{cm:AdditionalIcons}"; Flags: unchecked

[Files]
; Основной исполняемый файл
Source: "C:\Users\vanis\botanalyzer_fixed\dist\{#MyAppExeName}"; DestDir: "{app}"; Flags: ignoreversion

; Шаблон секретов (пользователь заполнит сам после установки)
Source: "C:\Users\vanis\botanalyzer_fixed\secret.env.example"; DestDir: "{app}"; Flags: ignoreversion

; requirements.txt — нужен для установки зависимостей через pip
Source: "C:\Users\vanis\botanalyzer_fixed\requirements.txt"; DestDir: "{app}"; Flags: ignoreversion

; Установщики Python, VLC и VC++ Redistributable
Source: "C:\Users\vanis\botanalyzer_fixed\installers\python-3.12.4-amd64.exe"; DestDir: "{tmp}"; Flags: deleteafterinstall
Source: "C:\Users\vanis\botanalyzer_fixed\installers\vlc-3.0.20-win64.exe"; DestDir: "{tmp}"; Flags: deleteafterinstall
Source: "C:\Users\vanis\botanalyzer_fixed\installers\VC_redist.x64.exe";    DestDir: "{tmp}"; Flags: deleteafterinstall

; Все .py файлы проекта (необходимы для работы бота)
Source: "C:\Users\vanis\botanalyzer_fixed\main.py";        DestDir: "{app}"; Flags: ignoreversion
Source: "C:\Users\vanis\botanalyzer_fixed\analyzer.py";    DestDir: "{app}"; Flags: ignoreversion
Source: "C:\Users\vanis\botanalyzer_fixed\transcriber.py"; DestDir: "{app}"; Flags: ignoreversion
Source: "C:\Users\vanis\botanalyzer_fixed\storage.py";     DestDir: "{app}"; Flags: ignoreversion
Source: "C:\Users\vanis\botanalyzer_fixed\sender.py";      DestDir: "{app}"; Flags: ignoreversion
Source: "C:\Users\vanis\botanalyzer_fixed\config.py";      DestDir: "{app}"; Flags: ignoreversion
Source: "C:\Users\vanis\botanalyzer_fixed\settings.py";    DestDir: "{app}"; Flags: ignoreversion
Source: "C:\Users\vanis\botanalyzer_fixed\achievements.py";DestDir: "{app}"; Flags: ignoreversion
Source: "C:\Users\vanis\botanalyzer_fixed\license.py";     DestDir: "{app}"; Flags: ignoreversion
Source: "C:\Users\vanis\botanalyzer_fixed\updater.py";     DestDir: "{app}"; Flags: ignoreversion
Source: "C:\Users\vanis\botanalyzer_fixed\gui_utils.py";   DestDir: "{app}"; Flags: ignoreversion
Source: "C:\Users\vanis\botanalyzer_fixed\gui_bot.py";     DestDir: "{app}"; Flags: ignoreversion
Source: "C:\Users\vanis\botanalyzer_fixed\gui_dialogs.py"; DestDir: "{app}"; Flags: ignoreversion

[Icons]
Name: "{autoprograms}\{#MyAppName}"; Filename: "{app}\{#MyAppExeName}"
Name: "{autodesktop}\{#MyAppName}";  Filename: "{app}\{#MyAppExeName}"; Tasks: desktopicon

[Run]
; 1. Установка VC++ Redistributable (если не установлен)
Filename: "{tmp}\VC_redist.x64.exe"; \
    Parameters: "/install /quiet /norestart"; \
    StatusMsg: "Установка Visual C++ Redistributable..."; \
    Check: NeedInstallVCRedist; \
    Flags: waituntilterminated

; 2. Установка Python (если не установлен)
Filename: "{tmp}\python-3.12.4-amd64.exe"; \
    Parameters: "/quiet InstallAllUsers=1 PrependPath=1 AssociateFiles=0"; \
    StatusMsg: "Установка Python 3.12.4..."; \
    Check: NeedInstallPython; \
    Flags: waituntilterminated

; 3. Установка VLC (если не установлен)
Filename: "{tmp}\vlc-3.0.20-win64.exe"; \
    Parameters: "/S"; \
    StatusMsg: "Установка VLC Media Player..."; \
    Check: NeedInstallVLC; \
    Flags: waituntilterminated

; 4. Установка Python-зависимостей через pip
;    Сначала обновляем pip
Filename: "{code:GetPythonExe}"; \
    Parameters: "-m pip install --upgrade pip --disable-pip-version-check --quiet"; \
    StatusMsg: "Обновление pip..."; \
    Flags: waituntilterminated runhidden

;    Затем устанавливаем зависимости из requirements.txt
Filename: "{code:GetPythonExe}"; \
    Parameters: "-m pip install -r ""{app}\requirements.txt"" --disable-pip-version-check --no-cache-dir --quiet"; \
    StatusMsg: "Установка зависимостей (может занять 5–15 минут)..."; \
    Flags: waituntilterminated runhidden

; 5. Создаём secret.env из примера (только если файла ещё нет)
;    Используем встроенную функцию, а не cmd (надёжнее)
Filename: "{app}\{#MyAppExeName}"; \
    Parameters: "/CreateEnv"; \
    StatusMsg: "Создание файла настроек..."; \
    Flags: waituntilterminated runhidden

; 6. Запуск приложения после установки
Filename: "{app}\{#MyAppExeName}"; \
    Description: "{cm:LaunchProgram,{#StringChange(MyAppName, '&', '&&')}}"; \
    Flags: nowait postinstall skipifsilent

[Code]

// --- Проверка: нужно ли ставить VC++ Redistributable ---
function NeedInstallVCRedist: Boolean;
begin
  // Проверяем наличие ключа для VC++ 2015-2022 (x64)
  if RegKeyExists(HKLM, 'SOFTWARE\Microsoft\VisualStudio\14.0\VC\Runtimes\X64') then
    Result := False
  else
    Result := True;
end;

// --- Проверка: нужно ли ставить Python ---
function NeedInstallPython: Boolean;
begin
  if RegKeyExists(HKLM, 'SOFTWARE\Python\PythonCore\3.12') or
     RegKeyExists(HKLM, 'SOFTWARE\WOW6432Node\Python\PythonCore\3.12') then
    Result := False
  else
    Result := True;
end;

// --- Проверка: нужно ли ставить VLC ---
function NeedInstallVLC: Boolean;
begin
  if RegKeyExists(HKLM, 'SOFTWARE\VideoLAN\VLC') or
     RegKeyExists(HKLM, 'SOFTWARE\WOW6432Node\VideoLAN\VLC') then
    Result := False
  else
    Result := True;
end;

// --- Получаем полный путь к python.exe (надёжно через реестр) ---
function GetPythonExe(Param: String): String;
var
  InstallPath: String;
begin
  if RegQueryStringValue(HKLM, 'SOFTWARE\Python\PythonCore\3.12\InstallPath',
                         '', InstallPath) then
  begin
    Result := InstallPath + 'python.exe';
    Exit;
  end;
  if RegQueryStringValue(HKCU, 'SOFTWARE\Python\PythonCore\3.12\InstallPath',
                         '', InstallPath) then
  begin
    Result := InstallPath + 'python.exe';
    Exit;
  end;
  Result := 'python.exe';  // последняя надежда на PATH
end;

// --- Копирование secret.env.example → secret.env (если нет) ---
procedure CreateSecretEnv;
var
  ExamplePath, EnvPath: String;
begin
  ExamplePath := ExpandConstant('{app}\secret.env.example');
  EnvPath := ExpandConstant('{app}\secret.env');
  if not FileExists(EnvPath) then
  begin
    if FileExists(ExamplePath) then
    begin
      if FileCopy(ExamplePath, EnvPath, False) then
        Log('Создан secret.env из примера.')
      else
        Log('Не удалось создать secret.env.');
    end
    else
      Log('Файл secret.env.example не найден.');
  end;
end;

// --- Выполнить после установки (создать secret.env) ---
procedure CurStepChanged(CurStep: TSetupStep);
begin
  if CurStep = ssPostInstall then
    CreateSecretEnv;
end;

// --- Предупреждение при деинсталляции ---
function InitializeUninstall(): Boolean;
begin
  if MsgBox('Удалить "Анализатор разговоров"?' + #13#10 +
            'Python, VLC и VC++ Redistributable НЕ будут удалены автоматически.',
            mbConfirmation, MB_YESNO) = IDYES then
    Result := True
  else
    Result := False;
end;