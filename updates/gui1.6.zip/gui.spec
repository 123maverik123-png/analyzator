# -*- mode: python ; coding: utf-8 -*-

block_cipher = None

from PyInstaller.utils.hooks import collect_all, collect_data_files, collect_dynamic_libs

# Собираем все компоненты для каждого пакета
vlc_datas, vlc_binaries, vlc_hidden = collect_all('vlc')
requests_datas, requests_binaries, requests_hidden = collect_all('requests')
dotenv_datas, dotenv_binaries, dotenv_hidden = collect_all('dotenv')
certifi_datas, certifi_binaries, certifi_hidden = collect_all('certifi')

# Для sv_ttk используем collect_data_files (гарантирует включение всех файлов данных)
sv_ttk_datas = collect_data_files('sv_ttk', include_py_files=True)
# Динамические библиотеки (если есть)
sv_ttk_binaries = collect_dynamic_libs('sv_ttk')
# Скрытые импорты
sv_ttk_hidden = ['sv_ttk']

# Объединяем все данные, бинарники и скрытые импорты
all_datas = vlc_datas + requests_datas + dotenv_datas + certifi_datas + sv_ttk_datas
all_binaries = vlc_binaries + requests_binaries + dotenv_binaries + certifi_binaries + sv_ttk_binaries
all_hiddenimports = vlc_hidden + requests_hidden + dotenv_hidden + certifi_hidden + sv_ttk_hidden

a = Analysis(
    ['gui.py'],
    pathex=[],
    binaries=all_binaries,
    datas=all_datas,
    hiddenimports=all_hiddenimports,
    hookspath=[],
    hooksconfig={},
    runtime_hooks=[],
    excludes=[],
    win_no_prefer_redirects=False,
    win_private_assemblies=False,
    cipher=block_cipher,
    noarchive=False,
)

pyz = PYZ(a.pure, a.zipped_data, cipher=block_cipher)

exe = EXE(
    pyz,
    a.scripts,
    a.binaries,
    a.zipfiles,
    a.datas,
    [],
    name='gui',
    debug=False,
    bootloader_ignore_signals=False,
    strip=False,
    upx=True,
    upx_exclude=[],
    runtime_tmpdir=None,
    console=False,
    disable_windowed_traceback=False,
    argv_emulation=False,
    target_arch=None,
    codesign_identity=None,
    entitlements_file=None,
    icon=None,  # укажите 'icon.ico', если есть
)