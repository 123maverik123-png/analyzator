# gui_bot.py — управление фоновым процессом main.py
import os
import sys
import subprocess
import threading
import shutil
import settings


class BotController:
    def __init__(self, log_callback):
        self.process       = None
        self.log_callback  = log_callback
        self.reader_thread = None

    def start(self):
        if self.is_running():
            return

        # ---------- Находим python-интерпретатор ----------
        if getattr(sys, 'frozen', False):
            # Запущено как EXE — ищем python рядом или в PATH
            python_exe = shutil.which('python') or shutil.which('python3')
            if not python_exe:
                self.log_callback("ОШИБКА: python не найден в PATH. Бот не запущен.")
                return
        else:
            python_exe = sys.executable

        # pythonw.exe не показывает stdout — заменяем на python.exe
        if python_exe and python_exe.lower().endswith('pythonw.exe'):
            candidate = python_exe[:-len('pythonw.exe')] + 'python.exe'
            python_exe = candidate if os.path.exists(candidate) else 'python'

        # ---------- Находим main.py ----------
        script_dir  = os.path.dirname(os.path.abspath(__file__))
        main_script = os.path.join(script_dir, "main.py")
        if not os.path.exists(main_script):
            # frozen: main.py лежит рядом с EXE
            exe_dir     = os.path.dirname(sys.executable)
            main_script = os.path.join(exe_dir, "main.py")
        if not os.path.exists(main_script):
            self.log_callback(f"ОШИБКА: main.py не найден ({main_script}). Бот не запущен.")
            return

        # ---------- Передаём актуальную папку записей через env ----------
        env = os.environ.copy()
        recordings_folder = settings.get("recordings_folder") or ""
        if recordings_folder:
            env["RECORDINGS_FOLDER_OVERRIDE"] = recordings_folder

        flags = subprocess.CREATE_NO_WINDOW if os.name == "nt" else 0

        try:
            self.process = subprocess.Popen(
                [python_exe, main_script],
                stdout=subprocess.PIPE,
                stderr=subprocess.STDOUT,
                text=True,
                encoding="utf-8",
                errors="replace",
                bufsize=1,
                cwd=script_dir,
                env=env,
                creationflags=flags,
            )
        except Exception as e:
            self.log_callback(f"ОШИБКА запуска бота: {e}")
            self.process = None
            return

        self.reader_thread = threading.Thread(target=self._read, daemon=True)
        self.reader_thread.start()

    def _read(self):
        while self.process and self.process.stdout:
            line = self.process.stdout.readline()
            if not line:
                break
            self.log_callback(line.strip())

    def stop(self):
        if not self.is_running():
            return
        try:
            self.process.terminate()
            self.process.wait(timeout=5)
        except Exception:
            try:
                self.process.kill()
            except Exception:
                pass
        finally:
            self.process = None

    def is_running(self):
        return self.process is not None and self.process.poll() is None
