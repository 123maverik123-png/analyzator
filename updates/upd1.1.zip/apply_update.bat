@echo off
timeout /t 2 /nobreak >nul
xcopy /E /I /Y "C:\Users\vanis\AppData\Local\Temp\tmp1ak5lu_s\extracted\*" "%~dp0"
start "" "C:\Users\vanis\botanalyzer_fixed\venv\Scripts\pythonw.exe" "gui.py"
exit
