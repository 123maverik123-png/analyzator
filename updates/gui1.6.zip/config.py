# config.py
import os
import sys
from dotenv import load_dotenv

# ---------- Единая папка для данных (в профиле пользователя) ----------
# Это гарантирует, что и EXE, и скрипт будут использовать одни и те же файлы.
APP_DATA_DIR = os.path.join(os.environ.get('APPDATA', os.path.expanduser('~')), 'MyCallAnalyzer')
os.makedirs(APP_DATA_DIR, exist_ok=True)

# ---------- Базовые пути ----------
# Для совместимости со старым кодом, но теперь они указывают на папку в %APPDATA%
BASE_DIR = APP_DATA_DIR

# ---------- Секреты (ищем в папке с EXE или в APP_DATA) ----------
# Сначала ищем в APP_DATA, потом рядом с EXE (для обратной совместимости)
SECRET_FILE = os.path.join(APP_DATA_DIR, "secret.env")
if not os.path.exists(SECRET_FILE):
    # Если в APP_DATA нет, пробуем рядом с EXE (для старых установок)
    exe_dir = os.path.dirname(sys.executable) if getattr(sys, 'frozen', False) else os.path.dirname(os.path.abspath(__file__))
    fallback = os.path.join(exe_dir, "secret.env")
    if os.path.exists(fallback):
        SECRET_FILE = fallback
load_dotenv(SECRET_FILE)

# ---------- Версия ----------
VERSION = "1.6"
UPDATE_BASE_URL = "https://raw.githubusercontent.com/123maverik123-png/analyzator/main/updates"

# ---------- Папка с записями (берётся из настроек GUI) ----------
import settings as _settings
def get_watch_folder():
    return _settings.get("recordings_folder")

WATCH_FOLDER = _settings.get("recordings_folder")

# ---------- Расширения аудиофайлов ----------
SUPPORTED_EXTENSIONS = (".mp3", ".wav", ".ogg", ".m4a", ".flac")

# ---------- Параметры Whisper ----------
WHISPER_MODEL   = "medium"
WHISPER_DEVICE  = "cpu"
WHISPER_COMPUTE = "int8"

# ---------- Диаризация ----------
DIARIZATION_ENABLED      = os.getenv("DIARIZATION_ENABLED", "1") != "0"
DIARIZATION_MODEL        = os.getenv("DIARIZATION_MODEL", "pyannote/speaker-diarization-community-1")
HF_TOKEN                 = os.getenv("HF_TOKEN", "")
DIARIZATION_NUM_SPEAKERS = 2

# ---------- Папка для отчётов (теперь в APP_DATA) ----------
OUTPUT_FOLDER = os.path.join(APP_DATA_DIR, "reports")
os.makedirs(OUTPUT_FOLDER, exist_ok=True)

# ---------- Модель тональности ----------
SENTIMENT_MODEL = "blanchefort/rubert-base-cased-sentiment"

# ---------- Оператор ----------
OPERATOR_ID = (
    os.getenv("OPERATOR_ID")
    or _settings.get("operator_id")
    or os.getenv("COMPUTERNAME")
    or "unknown"
)

def _machine_id():
    try:
        import winreg
        k   = winreg.OpenKey(winreg.HKEY_LOCAL_MACHINE, r"SOFTWARE\Microsoft\Cryptography")
        val, _ = winreg.QueryValueEx(k, "MachineGuid")
        winreg.CloseKey(k)
        return val
    except Exception:
        import uuid
        return f"{uuid.getnode():012x}"

MACHINE_ID = _machine_id()

# ---------- Центральный сервер ----------
CENTRAL_URL   = os.getenv("CENTRAL_URL",   "").rstrip("/")
CENTRAL_TOKEN = os.getenv("CENTRAL_TOKEN", "")

# ---------- Локальная БД (теперь в APP_DATA) ----------
LOCAL_DB = os.path.join(APP_DATA_DIR, "calls_local.db")