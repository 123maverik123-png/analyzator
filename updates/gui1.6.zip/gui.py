# gui.py — основной GUI-файл (с лицензией, логами, обновлениями, автозапуском бота, выделением новых записей)
import os
import sys
import queue
import threading
import tkinter as tk
from tkinter import ttk, scrolledtext, messagebox
from collections import deque
from datetime import datetime

import sv_ttk
import vlc
import settings
import storage
import achievements
import updater
import license

from gui_utils import fmt_time, extract_phone, extract_dt
from gui_bot import BotController
from gui_dialogs import DirChooser, NameDialog, ActivationDialog

storage.init_db()


class App:
    def __init__(self, root):
        self.root = root
        self.root.title("Анализатор разговоров")
        self.root.geometry("1060x720")
        self.root.minsize(900, 600)

        # Проверка лицензии — откладываем на 500 мс
        self.root.after(500, self._check_license)

        self.cfg = settings.load()
        sv_ttk.set_theme(self.cfg.get("theme", "dark"))

        # Очередь для логов
        self.ui_queue = queue.Queue()
        self._last_count = storage.count_calls()

        # История логов
        self.log_history = deque(maxlen=1000)
        self.log_window = None

        # Бот
        self.bot = BotController(self._on_bot_log)

        # Инициализация VLC
        self.vlc_instance = vlc.Instance()
        self.player = self.vlc_instance.media_player_new()
        self.current_media = None
        self.audio_duration = 0
        self.audio_position = 0
        self.is_playing = False
        self.is_paused = False
        self.is_seeking = False
        self.current_audio_path = None

        self._build_header()
        self._build_tabs()
        self._refresh_operator_label()

        self.load_calls()
        self.refresh_achievements()

        self._tick()
        self._poll()

        # --- Нижняя часть ---
        copyright_label = ttk.Label(
            self.root,
            text="© 2026 Все права защищены",
            foreground="#888",
            font=("Segoe UI", 8)
        )
        copyright_label.place(relx=1.0, rely=1.0, x=-10, y=-70, anchor="se")

        contact_label = ttk.Label(
            self.root,
            text="✉️ 123maverik123@gmail.com",
            foreground="#4a90e2",
            font=("Segoe UI", 8, "underline"),
            cursor="hand2"
        )
        contact_label.place(relx=1.0, rely=1.0, x=-10, y=-50, anchor="se")
        contact_label.bind("<Button-1>", lambda e: self._copy_email())

        bottom_left_frame = ttk.Frame(self.root)
        bottom_left_frame.place(relx=0.0, rely=1.0, x=10, y=-100, anchor="sw")

        self.license_label = ttk.Label(
            bottom_left_frame,
            text="",
            foreground="#888",
            font=("Segoe UI", 8)
        )
        self.license_label.pack(side=tk.LEFT)

        renew_link = ttk.Label(
            bottom_left_frame,
            text="Продлить подписку",
            foreground="#4a90e2",
            font=("Segoe UI", 8, "underline"),
            cursor="hand2"
        )
        renew_link.pack(side=tk.LEFT, padx=(10, 0))
        renew_link.bind("<Button-1>", lambda e: self.show_subscription())

        from config import VERSION
        version_label = ttk.Label(
            bottom_left_frame,
            text=f"Версия {VERSION}",
            foreground="#888",
            font=("Segoe UI", 8)
        )
        version_label.pack(side=tk.LEFT, padx=(15, 0))

        self._update_license_label()

        # Автообновление
        self.updater = updater.Updater(self.root, self.log_message)
        self.root.after(1000, lambda: self.updater.check_for_updates(silent=False))

        # При первом запуске, если оператор не задан, спросить
        if not (settings.get("operator_id") or os.getenv("OPERATOR_ID")):
            self.root.after(400, self._first_run_operator)

        # Автозапуск бота через 1 секунду после старта GUI
        self.root.after(1000, self._auto_start_bot)

        root.protocol("WM_DELETE_WINDOW", self.on_close)

    def _auto_start_bot(self):
        """Автоматический запуск бота при старте программы."""
        if not self.bot.is_running():
            self.bot.start()
            self.status.config(text="● работает", foreground="#3fb950")
            self.btn_restart.config(text="🔄 Перезапустить бота")
            self.log_message("Бот автоматически запущен")

    def restart_bot(self):
        """Перезапускает бота (останавливает и запускает заново)."""
        self.log_message("Перезапуск бота...")
        if self.bot.is_running():
            self.bot.stop()
            self.status.config(text="● остановлен", foreground="#e05656")
        self.bot.start()
        self.status.config(text="● работает", foreground="#3fb950")
        self.log_message("Бот перезапущен")

    # ---------- Логи ----------
    def log_message(self, msg):
        timestamp = datetime.now().strftime("%H:%M:%S")
        full_msg = f"[{timestamp}] {msg}"
        self.log_history.append(full_msg)
        self.root.after(0, lambda: self.log_var.set(full_msg))
        if self.log_window and self.log_window.winfo_exists():
            self._update_log_window()

    def _update_log_window(self):
        if not self.log_window or not self.log_window.winfo_exists():
            return
        text_widget = self.log_window.text_widget
        text_widget.config(state=tk.NORMAL)
        text_widget.delete("1.0", tk.END)
        text_widget.insert(tk.END, "\n".join(self.log_history))
        text_widget.see(tk.END)
        text_widget.config(state=tk.DISABLED)

    def open_log_window(self):
        if self.log_window and self.log_window.winfo_exists():
            self.log_window.lift()
            return
        self.log_window = tk.Toplevel(self.root)
        self.log_window.title("Логи")
        self.log_window.geometry("600x400")
        self.log_window.minsize(400, 300)

        frame = ttk.Frame(self.log_window, padding=10)
        frame.pack(fill=tk.BOTH, expand=True)

        text_widget = scrolledtext.ScrolledText(frame, wrap=tk.WORD, font=("Courier New", 10))
        text_widget.pack(fill=tk.BOTH, expand=True)
        self.log_window.text_widget = text_widget
        self._update_log_window()
        self.log_window.protocol("WM_DELETE_WINDOW", self._close_log_window)

    def _close_log_window(self):
        if self.log_window:
            self.log_window.destroy()
            self.log_window = None

    def _on_bot_log(self, msg):
        self.ui_queue.put(msg)

    # ---------- Лицензия ----------
    def _update_license_label(self):
        status = license.get_license_status()
        days_left = license.days_remaining()
        if status == "trial":
            text = f"🔓 Демо-период: {days_left} дн."
        elif status == "active":
            text = f"✅ Подписка активна: {days_left} дн."
        elif status == "expired":
            text = "❌ Демо-период истёк"
        else:
            if days_left > 0:
                text = f"⚠️ Сервер недоступен (grace: {days_left} дн.)"
            else:
                text = "⚠️ Статус лицензии неизвестен"
        self.license_label.config(text=text)

    def _check_license(self):
        status = license.get_license_status()
        if status == "expired":
            self._show_activation("expired")
            self._update_license_label()
        elif status == "error":
            if license.days_remaining() == 0:
                self._show_activation("error")
            self._update_license_label()

    def _show_activation(self, status):
        def on_activate(key):
            return license.activate_license(key)

        dialog = ActivationDialog(self.root, status, on_activate, exit_on_close=(status == "expired"))
        self.root.wait_window(dialog)
        if not dialog.result and status == "expired":
            sys.exit(0)

    # ---------- Шапка ----------
    def _build_header(self):
        bar = ttk.Frame(self.root, padding=(12, 6))
        bar.pack(fill=tk.X)

        self.op_label = ttk.Label(bar, text="", foreground="#888")
        self.op_label.pack(side=tk.LEFT, padx=(0, 12))

        self.btn_theme = ttk.Button(bar, width=3, command=self.toggle_theme,
                                    text="☀" if self.cfg.get("theme") == "dark" else "☽")
        self.btn_theme.pack(side=tk.RIGHT, padx=2)

        ttk.Button(bar, text="📋 Логи", command=self.open_log_window).pack(side=tk.RIGHT, padx=2)
        ttk.Button(bar, text="⚙ Папка записей", command=self.choose_folder).pack(side=tk.RIGHT, padx=2)
        ttk.Button(bar, text="🔄 Проверить обновления", command=self.check_updates_manual).pack(side=tk.RIGHT, padx=2)

        self.status = ttk.Label(bar, text="● остановлен", foreground="#e05656")
        self.status.pack(side=tk.RIGHT, padx=10)

        self.btn_restart = ttk.Button(bar, text="🔄 Перезапустить бота", command=self.restart_bot)
        self.btn_restart.pack(side=tk.RIGHT, padx=2)

    def toggle_theme(self):
        """Переключает тему между светлой и тёмной."""
        current = sv_ttk.get_theme()
        new = "light" if current == "dark" else "dark"
        sv_ttk.set_theme(new)
        settings.set("theme", new)
        self.btn_theme.config(text="☀" if new == "dark" else "☽")

    # ---------- Вкладки ----------
    def _build_tabs(self):
        nb = ttk.Notebook(self.root)
        nb.pack(fill=tk.BOTH, expand=True, padx=12, pady=(0, 6))
        self._build_calls_tab(nb)
        self._build_ach_tab(nb)

        self.log_var = tk.StringVar(value="Готово.")
        ttk.Label(self.root, textvariable=self.log_var, padding=(14, 2),
                  foreground="#888").pack(fill=tk.X)

    def _build_calls_tab(self, nb):
        tab = ttk.Frame(nb, padding=8)
        nb.add(tab, text="  Мои разговоры  ")

        paned = ttk.PanedWindow(tab, orient=tk.HORIZONTAL)
        paned.pack(fill=tk.BOTH, expand=True)

        left = ttk.Frame(paned)
        paned.add(left, weight=3)

        search_row = ttk.Frame(left)
        search_row.pack(fill=tk.X, pady=(0, 6))
        ttk.Label(search_row, text="🔍").pack(side=tk.LEFT, padx=(0, 4))
        self.search_var = tk.StringVar()
        self.search_var.trace_add("write", lambda *_: self.load_calls())
        ttk.Entry(search_row, textvariable=self.search_var).pack(fill=tk.X, expand=True)

        cols = ("phone", "date", "category", "resolved")
        self.tree = ttk.Treeview(left, columns=cols, show="headings", selectmode="browse")
        # Настройка тега для новых записей
        self.tree.tag_configure('new', font=('Segoe UI', 10, 'bold'))
        self.tree.bind('<Motion>', self._on_tree_motion)

        for c, t, w in (("phone", "Телефон", 120), ("date", "Дата/время", 130),
                        ("category", "Категория", 130), ("resolved", "✓", 40)):
            self.tree.heading(c, text=t)
            self.tree.column(c, width=w, anchor=tk.W)
        self.tree.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        sb = ttk.Scrollbar(left, orient=tk.VERTICAL, command=self.tree.yview)
        self.tree.configure(yscrollcommand=sb.set)
        sb.pack(side=tk.RIGHT, fill=tk.Y)
        self.tree.bind("<<TreeviewSelect>>", lambda e: self.on_select())

        right = ttk.Frame(paned)
        paned.add(right, weight=2)

        self.detail_head = ttk.Label(right, text="Выберите разговор", font=("Segoe UI", 12, "bold"))
        self.detail_head.pack(anchor=tk.W)
        self.detail_meta = ttk.Label(right, text="", foreground="#888", wraplength=380, justify=tk.LEFT)
        self.detail_meta.pack(anchor=tk.W, pady=(2, 8))

        ttk.Label(right, text="Резюме", font=("Segoe UI", 9, "bold")).pack(anchor=tk.W)
        self.detail_summary = ttk.Label(right, text="—", wraplength=380, justify=tk.LEFT)
        self.detail_summary.pack(anchor=tk.W, pady=(0, 4))
        self.btn_copy = ttk.Button(right, text="📋 Копировать резюме",
                                   command=self.copy_summary, state=tk.DISABLED)
        self.btn_copy.pack(anchor=tk.W, pady=(0, 8))
        self.current_summary = ""

        self.detail_text_label = ttk.Label(right, text="Расшифровка", font=("Segoe UI", 9, "bold"))
        self.detail_text_label.pack(anchor=tk.W)
        self.detail_text = scrolledtext.ScrolledText(right, wrap=tk.WORD, height=10,
                                                     font=("Segoe UI", 10), relief=tk.FLAT)
        self.detail_text.pack(fill=tk.BOTH, expand=True, pady=(2, 8))

        self._build_player(tab)
        self.player_frame.pack_forget()

    def _build_player(self, parent):
        self.player_frame = ttk.Frame(parent, padding=(0, 8, 0, 0))
        bar = self.player_frame
        self.btn_back = ttk.Button(bar, text="⏪10", width=5, command=lambda: self.skip(-10), state=tk.DISABLED)
        self.btn_back.pack(side=tk.LEFT)
        self.btn_play = ttk.Button(bar, text="▶", width=4, command=self.toggle_play, state=tk.DISABLED)
        self.btn_play.pack(side=tk.LEFT, padx=4)
        self.btn_stop = ttk.Button(bar, text="⏹", width=4, command=self.stop_play, state=tk.DISABLED)
        self.btn_stop.pack(side=tk.LEFT)
        self.btn_fwd = ttk.Button(bar, text="10⏩", width=5, command=lambda: self.skip(10), state=tk.DISABLED)
        self.btn_fwd.pack(side=tk.LEFT, padx=4)
        self.player_btns = [self.btn_back, self.btn_play, self.btn_stop, self.btn_fwd]

        self.pos_var = tk.DoubleVar(value=0)
        self.scale = ttk.Scale(bar, from_=0, to=100, variable=self.pos_var)
        self.scale.pack(side=tk.LEFT, fill=tk.X, expand=True, padx=10)
        self.scale.bind("<ButtonPress-1>", lambda e: setattr(self, "is_seeking", True))
        self.scale.bind("<ButtonRelease-1>", self._on_seek)
        self.scale.bind("<B1-Motion>", self._on_scale_drag)

        self.time_lbl = ttk.Label(bar, text="00:00 / 00:00", width=14)
        self.time_lbl.pack(side=tk.LEFT)
        self.file_lbl = ttk.Label(bar, text="", foreground="#888")
        self.file_lbl.pack(side=tk.LEFT, padx=10)

    def _build_ach_tab(self, nb):
        tab = ttk.Frame(nb, padding=16)
        nb.add(tab, text="  Достижения  ")

        top = ttk.Frame(tab)
        top.pack(fill=tk.X, pady=(0, 14))
        self.level_lbl = ttk.Label(top, text="Уровень 1", font=("Segoe UI", 16, "bold"))
        self.level_lbl.pack(side=tk.LEFT)
        self.xp_lbl = ttk.Label(top, text="", foreground="#888")
        self.xp_lbl.pack(side=tk.RIGHT)
        self.xp_bar = ttk.Progressbar(tab, maximum=1.0, value=0)
        self.xp_bar.pack(fill=tk.X, pady=(0, 18))

        self.ach_grid = ttk.Frame(tab)
        self.ach_grid.pack(fill=tk.BOTH, expand=True)
        for i in range(2):
            self.ach_grid.columnconfigure(i, weight=1, uniform="ach")

    # ---------- Данные: разговоры ----------
    def load_calls(self):
        q = self.search_var.get().lower().strip() if hasattr(self, "search_var") else ""
        sel = self.tree.selection()
        sel_id = self.tree.item(sel[0], "tags")[0] if sel else None

        # Запоминаем текущие ID до очистки
        current_ids = set()
        for item in self.tree.get_children():
            current_ids.add(self.tree.item(item, "tags")[0])
        self.last_loaded_ids = current_ids

        self.tree.delete(*self.tree.get_children())

        # Новые ID — те, что есть в БД, но не было в прошлой загрузке
        new_ids = set()
        for c in storage.get_all_calls():
            cid = c["call_id"]
            if cid not in self.last_loaded_ids:
                new_ids.add(cid)

        self.new_call_ids = new_ids  # запоминаем новые

        for c in storage.get_all_calls():
            cid = c["call_id"]
            hay = f"{extract_phone(cid)} {c.get('category') or ''} {c.get('problem') or ''}".lower()
            if q and q not in hay:
                continue
            tags = ('new',) if cid in self.new_call_ids else ()
            iid = self.tree.insert("", tk.END, tags=(cid,) + tags, values=(
                extract_phone(cid), extract_dt(cid), c.get("category") or "—",
                "✅" if c.get("is_resolved") else "❌"))
            if cid == sel_id:
                self.tree.selection_set(iid)

    def _on_tree_motion(self, event):
        """Убирает выделение 'new' при наведении на строку."""
        item = self.tree.identify_row(event.y)
        if item:
            tags = self.tree.item(item, "tags")
            if 'new' in tags:
                # Убираем тег 'new'
                new_tags = [t for t in tags if t != 'new']
                self.tree.item(item, tags=new_tags)
                # Удаляем ID из набора новых
                cid = self.tree.item(item, "tags")[0]
                if cid in self.new_call_ids:
                    self.new_call_ids.remove(cid)

    def on_select(self):
        sel = self.tree.selection()
        if not sel:
            return
        cid = self.tree.item(sel[0], "tags")[0]
        call = storage.get_call(cid)
        if not call:
            return
        self.detail_head.config(text=extract_phone(cid))
        neg, neu, pos = call.get("sent_neg") or 0, call.get("sent_neu") or 0, call.get("sent_pos") or 0
        self.detail_meta.config(text=(
            f"{extract_dt(cid)}   ·   {call.get('category') or '—'}   ·   "
            f"{'решено' if call.get('is_resolved') else 'не решено'}\n"
            f"Тональность: 😟 {neg:.0%}  ·  😐 {neu:.0%}  ·  🙂 {pos:.0%}\n"
            f"Проблема: {call.get('problem') or '—'}\nДействие: {call.get('action') or '—'}"))
        self.current_summary = call.get("summary") or ""
        self.detail_summary.config(text=self.current_summary or "—")
        self.btn_copy.config(state=(tk.NORMAL if self.current_summary else tk.DISABLED))
        dialogue = call.get("dialogue_text")
        self.detail_text_label.config(
            text="Расшифровка (по голосам)" if dialogue else "Расшифровка")
        self.detail_text.config(state=tk.NORMAL)
        self.detail_text.delete("1.0", tk.END)
        self.detail_text.insert(tk.END, dialogue or call.get("full_text") or "—")
        self.detail_text.config(state=tk.DISABLED)
        self._load_audio(cid)

    # ---------- Плеер (без автовоспроизведения) ----------
    def _load_audio(self, call_id):
        self.stop_play()
        self.current_audio_path = os.path.join(settings.get("recordings_folder"), call_id)
        if not os.path.exists(self.current_audio_path):
            self.file_lbl.config(text="файл записи не найден")
            self._set_player_state(tk.DISABLED)
            self.time_lbl.config(text="00:00 / 00:00")
            self.audio_duration = 0
            self.player_frame.pack_forget()
            return
        try:
            self.current_media = self.vlc_instance.media_new(self.current_audio_path)
            self.player.set_media(self.current_media)
            # НЕ вызываем self.player.play() — убрано автовоспроизведение
            self.root.after(200, self._update_duration)
            self._set_player_state(tk.NORMAL)
            self.file_lbl.config(text=call_id)
            self.audio_duration = 0
            self.audio_position = 0
            self.is_playing = False
            self.is_paused = False
            self.btn_play.config(text="▶")
            self.pos_var.set(0)
            self.time_lbl.config(text="00:00 / 00:00")
            self.player_frame.pack(fill=tk.X, pady=(8, 0))
        except Exception as e:
            self.file_lbl.config(text=f"ошибка аудио: {e}")
            self._set_player_state(tk.DISABLED)
            self.time_lbl.config(text="00:00 / 00:00")
            self.player_frame.pack_forget()

    def _update_duration(self):
        if self.player:
            dur = self.player.get_length() / 1000.0
            if dur > 0:
                self.audio_duration = dur
                self.scale.config(to=max(dur, 1))
                self.time_lbl.config(text=f"00:00 / {fmt_time(dur)}")
            else:
                self.root.after(1000, self._update_duration)

    def _set_player_state(self, state):
        for b in self.player_btns:
            b.config(state=state)
        self.btn_play.config(text="▶")

    def toggle_play(self):
        if not self.current_audio_path:
            return
        if self.is_playing:
            self.player.pause()
            self.is_playing = False
            self.is_paused = True
            self.btn_play.config(text="▶")
        elif self.is_paused:
            self.player.play()
            self.is_playing = True
            self.is_paused = False
            self.btn_play.config(text="⏸")
        else:
            self.player.play()
            self.is_playing = True
            self.is_paused = False
            self.btn_play.config(text="⏸")

    def _on_scale_drag(self, event):
        if self.audio_duration > 0:
            new_pos = self.pos_var.get()
            if new_pos < 0:
                new_pos = 0
            if new_pos > self.audio_duration:
                new_pos = self.audio_duration
            self.time_lbl.config(text=f"{fmt_time(new_pos)} / {fmt_time(self.audio_duration)}")

    def _on_seek(self, _event):
        if self.player and self.audio_duration > 0:
            new_pos = self.pos_var.get()
            if new_pos < 0:
                new_pos = 0
            if new_pos > self.audio_duration:
                new_pos = self.audio_duration
            self.player.set_time(int(new_pos * 1000))
            self.audio_position = new_pos
            self.time_lbl.config(text=f"{fmt_time(new_pos)} / {fmt_time(self.audio_duration)}")
        self.is_seeking = False

    def skip(self, delta):
        if not self.player or self.audio_duration == 0:
            return
        current = self.player.get_time() / 1000.0
        new_pos = max(0, min(current + delta, self.audio_duration - 0.2))
        self.player.set_time(int(new_pos * 1000))
        self.audio_position = new_pos
        self.pos_var.set(new_pos)
        self.time_lbl.config(text=f"{fmt_time(new_pos)} / {fmt_time(self.audio_duration)}")

    def stop_play(self):
        if self.player:
            self.player.stop()
        self.is_playing = False
        self.is_paused = False
        self.btn_play.config(text="▶")
        self.audio_position = 0
        self.pos_var.set(0)
        self.time_lbl.config(text=f"00:00 / {fmt_time(self.audio_duration)}")

    def _tick(self):
        if self.is_playing and not self.is_seeking and self.player:
            try:
                pos_ms = self.player.get_time()
                if pos_ms != -1 and self.audio_duration > 0:
                    self.audio_position = pos_ms / 1000.0
                    self.pos_var.set(self.audio_position)
                    self.time_lbl.config(text=f"{fmt_time(self.audio_position)} / {fmt_time(self.audio_duration)}")
            except Exception:
                pass
            state = self.player.get_state()
            if state == vlc.State.Ended or state == vlc.State.Stopped:
                if self.is_playing:
                    self.is_playing = False
                    self.is_paused = False
                    self.btn_play.config(text="▶")
                    self.audio_position = self.audio_duration
                    self.pos_var.set(self.audio_duration)
                    self.time_lbl.config(text=f"{fmt_time(self.audio_duration)} / {fmt_time(self.audio_duration)}")
        self.root.after(300, self._tick)

    def refresh_achievements(self):
        stats = storage.get_stats()
        newly = achievements.sync_unlocks(stats)
        xp = achievements.xp_for(stats)
        level, into, needed, frac = achievements.level_info(xp)
        self.level_lbl.config(text=f"Уровень {level}")
        self.xp_lbl.config(text=f"XP {xp}  ·  до след. уровня {needed - into}")
        self.xp_bar.config(value=frac)

        for w in self.ach_grid.winfo_children():
            w.destroy()
        for idx, a in enumerate(achievements.evaluate(stats)):
            self._ach_card(self.ach_grid, a, idx // 2, idx % 2)

        for a in newly:
            messagebox.showinfo("Новое достижение!", f"{a['icon']}  {a['title']}\n{a['desc']}")

    def _ach_card(self, parent, a, r, c):
        card = ttk.Frame(parent, padding=12, relief=tk.SOLID, borderwidth=1)
        card.grid(row=r, column=c, sticky="nsew", padx=6, pady=6)
        unlocked = a["unlocked"]
        head = ttk.Frame(card)
        head.pack(fill=tk.X)
        ttk.Label(head, text=a["icon"], font=("Segoe UI", 18)).pack(side=tk.LEFT, padx=(0, 8))
        title = ttk.Label(head, text=a["title"], font=("Segoe UI", 11, "bold"),
                          foreground=("" if unlocked else "#888"))
        title.pack(side=tk.LEFT)
        if unlocked:
            ttk.Label(head, text="✓", foreground="#3fb950",
                      font=("Segoe UI", 12, "bold")).pack(side=tk.RIGHT)
        ttk.Label(card, text=a["desc"], foreground="#888").pack(anchor=tk.W, pady=(4, 6))
        ttk.Progressbar(card, maximum=1.0, value=a["progress"]).pack(fill=tk.X)
        ttk.Label(card, text=f"{a['current']} / {a['target']}",
                  foreground="#888").pack(anchor=tk.E, pady=(2, 0))

    def toggle_theme(self):
        """Переключает тему между светлой и тёмной."""
        current = sv_ttk.get_theme()
        new = "light" if current == "dark" else "dark"
        sv_ttk.set_theme(new)
        settings.set("theme", new)
        self.btn_theme.config(text="☀" if new == "dark" else "☽")

    def _operator(self):
        return (settings.get("operator_id") or os.getenv("OPERATOR_ID")
                or os.getenv("COMPUTERNAME") or "не задан")

    def _refresh_operator_label(self):
        self.op_label.config(text=f"👤 {self._operator()}")

    def _first_run_operator(self):
        result = NameDialog(self.root).result
        if result:
            settings.set("operator_id", result)
            self._refresh_operator_label()

    def copy_summary(self):
        text = (self.current_summary or "").strip()
        if not text:
            return
        self.root.clipboard_clear()
        self.root.clipboard_append(text)
        self.root.update()
        self.log_var.set("✔ Резюме скопировано в буфер обмена")

    def _copy_email(self):
        email = "123maverik123@gmail.com"
        self.root.clipboard_clear()
        self.root.clipboard_append(email)
        self.root.update()
        self.log_var.set("✉️ Email скопирован в буфер обмена")

    def choose_folder(self):
        initial = settings.get("recordings_folder") or os.path.expanduser("~")
        if not os.path.isdir(initial):
            initial = os.path.expanduser("~")
        folder = DirChooser(self.root, initial).result
        if folder:
            settings.set("recordings_folder", folder)
            messagebox.showinfo("Папка изменена",
                                "Папка сохранена.\nЕсли бот запущен — перезапустите его, чтобы он следил за новой папкой.",
                                parent=self.root)

    def check_updates_manual(self):
        self.updater.check_for_updates(silent=False)

    def show_subscription(self):
        def on_activate(key):
            return license.activate_license(key)
        dialog = ActivationDialog(self.root, "active", on_activate, exit_on_close=False)
        self.root.wait_window(dialog)
        if dialog.result:
            messagebox.showinfo("Успех", "Подписка обновлена.")
            self._update_license_label()

    def _poll(self):
        try:
            while True:
                self.log_var.set(self.ui_queue.get_nowait()[:120])
        except queue.Empty:
            pass
        try:
            cur = storage.count_calls()
            if cur != self._last_count:
                self._last_count = cur
                self.load_calls()
                self.refresh_achievements()
        except Exception:
            pass
        self.root.after(1000, self._poll)

    def on_close(self):
        if self.player:
            self.player.stop()
        if self.bot.is_running():
            self.bot.stop()
        self.root.destroy()


if __name__ == "__main__":
    root = tk.Tk()
    App(root)
    root.mainloop()