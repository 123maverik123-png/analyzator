# analyzer.py
import os
import json
import requests
import torch
from transformers import AutoTokenizer, AutoModelForSequenceClassification
from dotenv import load_dotenv
from config import SENTIMENT_MODEL, SECRET_FILE

# Загрузка секретов
load_dotenv(SECRET_FILE)

# ---------- Тональность (rubert) ----------
tokenizer = None
sentiment_model = None

def load_sentiment_model():
    global tokenizer, sentiment_model
    if tokenizer is None:
        print("Загрузка модели тональности...")
        tokenizer = AutoTokenizer.from_pretrained(SENTIMENT_MODEL)
        sentiment_model = AutoModelForSequenceClassification.from_pretrained(SENTIMENT_MODEL)
        print("Модель тональности загружена.")

def analyze_sentiment(text):
    load_sentiment_model()
    inputs = tokenizer(
        text,
        return_tensors="pt",
        truncation=True,
        max_length=512,
        padding=True
    )
    with torch.no_grad():
        outputs = sentiment_model(**inputs)
    probs = torch.softmax(outputs.logits, dim=1).squeeze().tolist()
    return {
        "negative": probs[0],
        "neutral":  probs[1],
        "positive": probs[2]
    }

# ---------- YandexGPT (нативный REST API v1) ----------
def get_yandex_gpt_credentials():
    api_key   = os.getenv("YC_API_KEY")
    folder_id = os.getenv("YC_FOLDER_ID")
    if not api_key or not folder_id:
        raise ValueError(
            "YC_API_KEY и YC_FOLDER_ID должны быть установлены в файле secret.env"
        )
    return api_key, folder_id


def analyze_with_yandex_gpt(transcript):
    """Анализирует расшифровку разговора через YandexGPT REST API."""
    api_key, folder_id = get_yandex_gpt_credentials()

    prompt = f"""Ты — аналитик службы поддержки интернет-провайдера.
Проанализируй следующий диалог между сотрудником и абонентом.
Если реплики помечены [Оператор]/[Абонент] — это результат автоматического
разделения голосов и метки могут изредка ошибаться местами, учитывай это.
Ответь строго в формате JSON с полями:
1. "problem" — суть проблемы абонента (одно-два предложения).
2. "category" — категория обращения, ровно одно из значений:
   "нет интернета", "низкая скорость", "обрывы связи", "wi-fi/роутер",
   "оплата/баланс", "подключение/настройка", "телевидение", "другое".
3. "is_resolved" — true, если проблема решена, иначе false.
4. "action" — что именно сделал сотрудник для решения (кратко).
5. "summary" — краткое резюме всего разговора (одно предложение).

Диалог:
{transcript}
"""

    url = "https://llm.api.cloud.yandex.net/foundationModels/v1/completion"
    headers = {
        "Authorization": f"Api-Key {api_key}",
        "Content-Type":  "application/json",
    }
    body = {
        "modelUri": f"gpt://{folder_id}/yandexgpt-lite",
        "completionOptions": {
            "stream":      False,
            "temperature": 0.2,
            "maxTokens":   1000,
        },
        "messages": [
            {"role": "user", "text": prompt},
        ],
    }

    raw_response = None
    try:
        resp = requests.post(url, headers=headers, json=body, timeout=60)
        resp.raise_for_status()
        data         = resp.json()
        raw_response = data["result"]["alternatives"][0]["message"]["text"]

        # Вырезаем JSON из ответа
        start = raw_response.find('{')
        end   = raw_response.rfind('}') + 1
        if start != -1 and end > start:
            json_str = raw_response[start:end]
            return json.loads(json_str)
        return {"error": "Не найден JSON в ответе", "raw": raw_response}

    except requests.HTTPError as e:
        msg = str(e)
        if "does not match with service account folder ID" in msg:
            msg = (
                "YC_FOLDER_ID в secret.env не совпадает с тем, к которому привязан "
                "сервисный аккаунт YC_API_KEY. Проверьте folder_id в консоли Yandex Cloud "
                f"и поправьте secret.env. Исходная ошибка: {msg}"
            )
        return {"error": msg, "raw": raw_response}
    except Exception as e:
        return {"error": str(e), "raw": raw_response}


def analyze_full(transcript, llm_input_text=None):
    """Тональность — по чистой расшифровке; LLM-анализ — по диалогу с метками (если есть)."""
    sentiment  = analyze_sentiment(transcript)
    llm_result = analyze_with_yandex_gpt(llm_input_text or transcript)
    return {
        "sentiment":    sentiment,
        "llm_analysis": llm_result,
        "full_text":    transcript,
    }
