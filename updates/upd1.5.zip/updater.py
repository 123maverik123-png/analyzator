# updater.py — автообновление через GitHub с улучшениями
import os
import sys
import json
import hashlib
import tempfile
import zipfile
import shutil
import subprocess
import threading
from threading import Thread
import requests
from config import VERSION, UPDATE_BASE_URL
from tkinter import messagebox

# Базовая директория: рядом с EXE или со скриптом
BASE_DIR = os.path.dirname(sys.executable) if getattr(sys, 'frozen', False) \
           else os.path.dirname(os.path.abspath(__file__))


class Updater:
    def __init__(self, root, log_callback):
        self.root = root
        self.log = log_callback
        self.thread = None

    def check_for_updates(self, silent=False):
        if self.thread and self.thread.is_alive():
            return
        self.thread = Thread(target=self._check, args=(silent,), daemon=True)
        self.thread.start()

    def _check(self, silent):
        try:
            self.log("[Обновления] Проверка наличия обновлений...")
            version_url = f"{UPDATE_BASE_URL}/version.json"
            resp = requests.get(version_url, timeout=10)
            if resp.status_code != 200:
                self.log(f"[Обновления] Не удалось получить version.json (код {resp.status_code})")
                return

            data = resp.json()
            latest_version = data.get("version")
            if not latest_version:
                self.log("[Обновления] version.json не содержит поле 'version'.")
                return

            if latest_version == VERSION:
                if not silent:
                    self.log(f"[Обновления] У вас актуальная версия {VERSION}.")
                return

            self.log(f"[Обновления] Доступна новая версия {latest_version} (текущая {VERSION}).")
            # Диалог нужно открывать в главном потоке
            self.root.after(0, lambda: self._ask_update(data, latest_version))

        except requests.exceptions.ConnectionError:
            if not silent:
                self.log("[Обновления] Нет соединения с сервером обновлений.")
        except requests.exceptions.Timeout:
            if not silent:
                self.log("[Обновления] Таймаут при проверке обновлений.")
        except Exception as e:
            self.log(f"[Обновления] Ошибка при проверке: {e}")

    def _ask_update(self, data, new_version):
        changelog = data.get("changelog", "Исправлены ошибки и улучшена производительность.")
        answer = messagebox.askyesno(
            "Обновление",
            f"Доступна новая версия {new_version}.\n\nИзменения:\n{changelog}\n\nОбновить сейчас?",
            parent=self.root
        )
        if answer:
            # Скачивание запускаем в фоне, чтобы не блокировать GUI
            Thread(target=self._apply_update, args=(data, new_version), daemon=True).start()

    def _hash_file(self, file_path):
        sha256_hash = hashlib.sha256()
        with open(file_path, "rb") as f:
            for byte_block in iter(lambda: f.read(4096), b""):
                sha256_hash.update(byte_block)
        return sha256_hash.hexdigest()

    def _apply_update(self, data, new_version):
        # --- Проверка версии Python ---
        required_python = data.get("python_version", "3.12")
        try:
            required_tuple = tuple(map(int, required_python.split('.')))
        except ValueError:
            required_tuple = (3, 12)
        if sys.version_info < required_tuple:
            self.root.after(0, lambda: messagebox.showerror(
                "Ошибка",
                f"Для этой версии требуется Python {required_python} или выше.",
                parent=self.root
            ))
            return

        download_url = data.get("download_url")
        if not download_url:
            self.root.after(0, lambda: messagebox.showerror(
                "Ошибка", "Не удалось получить ссылку для скачивания.", parent=self.root
            ))
            return

        # --- Резервная копия ---
        backup_dir = os.path.join(BASE_DIR, "backup_" + VERSION)
        self.log(f"[Обновления] Создание резервной копии в {backup_dir}")
        try:
            os.makedirs(backup_dir, exist_ok=True)
            for file in os.listdir(BASE_DIR):  # используем BASE_DIR, не os.listdir(".")
                if file.endswith(".py") or file.endswith(".bat") or file == "requirements.txt":
                    shutil.copy2(os.path.join(BASE_DIR, file), backup_dir)
        except Exception as e:
            self.log(f"[Обновления] Не удалось создать бэкап: {e}")

        temp_dir = tempfile.mkdtemp()
        zip_path = os.path.join(temp_dir, "update.zip")
        extract_path = os.path.join(temp_dir, "extracted")

        try:
            # --- Скачивание ---
            self.log("[Обновления] Скачивание обновления...")
            with requests.get(download_url, stream=True, timeout=60) as r:
                r.raise_for_status()
                with open(zip_path, "wb") as f:
                    for chunk in r.iter_content(chunk_size=8192):
                        f.write(chunk)

            self.log(f"[Обновления] Размер скачанного файла: {os.path.getsize(zip_path)} байт")

            # --- Проверка SHA-256 ---
            sha256 = data.get("sha256")
            if sha256:
                self.log("[Обновления] Проверка целостности...")
                computed_hash = self._hash_file(zip_path)
                self.log(f"  Ожидаемый хеш:   {sha256}")
                self.log(f"  Вычисленный хеш: {computed_hash}")
                if computed_hash.lower() != sha256.lower():
                    self.root.after(0, lambda: messagebox.showerror(
                        "Ошибка",
                        "Контрольная сумма не совпадает. Обновление отменено.",
                        parent=self.root
                    ))
                    return
            else:
                self.log("[Обновления] ⚠️  SHA-256 не указан в version.json — пропускаем проверку.")

            # --- Распаковка ---
            self.log("[Обновления] Распаковка...")
            os.makedirs(extract_path, exist_ok=True)
            with zipfile.ZipFile(zip_path, 'r') as zip_ref:
                zip_ref.extractall(extract_path)

            # --- Установка зависимостей ---
            req_path = os.path.join(extract_path, "requirements.txt")
            if os.path.exists(req_path):
                self.log("[Обновления] Установка зависимостей...")
                result = subprocess.run(
                    [sys.executable, "-m", "pip", "install", "-r", req_path],
                    capture_output=True, text=True
                )
                if result.returncode != 0:
                    self.log(f"[Обновления] ⚠️  pip вернул ошибку:\n{result.stderr[:300]}")

            # --- Применение ---
            self.log("[Обновления] Применение обновления...")
            self._launch_updater_script(extract_path)

        except requests.exceptions.Timeout:
            self.log("[Обновления] Таймаут при скачивании обновления.")
            self.root.after(0, lambda: messagebox.showerror(
                "Ошибка", "Таймаут при скачивании обновления.", parent=self.root
            ))
        except Exception as e:
            self.log(f"[Обновления] Ошибка: {e}")
            self.root.after(0, lambda err=e: messagebox.showerror(
                "Ошибка", f"Не удалось применить обновление: {err}", parent=self.root
            ))
        finally:
            # Всегда чистим временную папку
            try:
                shutil.rmtree(temp_dir, ignore_errors=True)
            except Exception:
                pass

    def _launch_updater_script(self, update_dir):
        # Нормализуем путь: убираем trailing-слеш, чтобы xcopy не спрашивал «файл или папка?»
        update_dir = os.path.normpath(update_dir)
        target_dir = os.path.normpath(BASE_DIR)

        bat_content = f"""@echo off
timeout /t 2 /nobreak >nul
xcopy /E /I /Y "{update_dir}\\*" "{target_dir}\\"
start "" "{sys.executable}" "{os.path.join(target_dir, 'gui.py')}"
exit
"""
        bat_path = os.path.join(BASE_DIR, "apply_update.bat")
        with open(bat_path, "w", encoding="utf-8") as f:
            f.write(bat_content)

        # creationflags только на Windows; на других ОС — 0
        flags = subprocess.CREATE_NO_WINDOW if os.name == "nt" else 0
        subprocess.Popen(bat_path, creationflags=flags, shell=(os.name != "nt"))

        # Завершаем GUI через 2 секунды (даём .bat время стартовать)
        threading.Timer(2, self.root.quit).start()
