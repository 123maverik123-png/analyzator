# gui_bot.py — управление фоновым процессом main.py
import os
import sys
import subprocess
import threading
import shutil


class BotController:
    def __init__(self, log_callback):
        self.process = None
        self.log_callback = log_callback
        self.reader_thread = None

    def start(self):
        if self.is_running():
            return

        # Ищем python.exe (системный или из venv)
        python_exe = shutil.which('python')
        if not python_exe:
            # Если не найден, пробуем sys.executable
            python_exe = sys.executable

        # Если это pythonw.exe, заменяем на python.exe
        if python_exe and python_exe.lower().endswith('pythonw.exe'):
            python_exe = python_exe[:-4] + 'exe'
            if not os.path.exists(python_exe):
                python_exe = 'python'  # надеемся, что он в PATH

        # Путь к main.py (рядом с EXE)
        main_script = os.path.join(os.path.dirname(sys.executable), "main.py")
        if not os.path.exists(main_script):
            # Если рядом с EXE нет main.py, пробуем в текущей папке
            main_script = "main.py"

        flags = subprocess.CREATE_NO_WINDOW if os.name == "nt" else 0

        self.process = subprocess.Popen(
            [python_exe, main_script],
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
            text=True,
            encoding="utf-8",
            errors="replace",
            bufsize=1,
            cwd=os.path.dirname(os.path.abspath(__file__)),
            creationflags=flags,
        )
        self.reader_thread = threading.Thread(target=self._read, daemon=True)
        self.reader_thread.start()

    def _read(self):
        while self.process and self.process.stdout:
            line = self.process.stdout.readline()
            if not line:
                break
            self.log_callback(line.strip())

    def stop(self):
        if not self.is_running():
            return
        try:
            self.process.terminate()
            self.process.wait(timeout=5)
        except Exception:
            self.process.kill()
        finally:
            self.process = None

    def is_running(self):
        return self.process is not None and self.process.poll() is None