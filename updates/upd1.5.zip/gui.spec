# -*- mode: python ; coding: utf-8 -*-

block_cipher = None

from PyInstaller.utils.hooks import collect_all

# Собираем все компоненты для каждого пакета
vlc_datas, vlc_binaries, vlc_hidden = collect_all('vlc')
requests_datas, requests_binaries, requests_hidden = collect_all('requests')
dotenv_datas, dotenv_binaries, dotenv_hidden = collect_all('dotenv')
sv_ttk_datas, sv_ttk_binaries, sv_ttk_hidden = collect_all('sv_ttk')
certifi_datas, certifi_binaries, certifi_hidden = collect_all('certifi')

# Объединяем все данные, бинарники и скрытые импорты
all_datas = vlc_datas + requests_datas + dotenv_datas + sv_ttk_datas + certifi_datas
all_binaries = vlc_binaries + requests_binaries + dotenv_binaries + sv_ttk_binaries + certifi_binaries
all_hiddenimports = vlc_hidden + requests_hidden + dotenv_hidden + sv_ttk_hidden + certifi_hidden

a = Analysis(
    ['gui.py'],
    pathex=[],
    binaries=all_binaries,
    datas=all_datas,
    hiddenimports=all_hiddenimports + ['certifi'],
    hookspath=[],
    hooksconfig={},
    runtime_hooks=[],
    excludes=[],
    win_no_prefer_redirects=False,
    win_private_assemblies=False,
    cipher=block_cipher,
    noarchive=False,
)

pyz = PYZ(a.pure, a.zipped_data, cipher=block_cipher)

exe = EXE(
    pyz,
    a.scripts,
    a.binaries,
    a.zipfiles,
    a.datas,
    [],
    name='gui',
    debug=False,
    bootloader_ignore_signals=False,
    strip=False,
    upx=True,
    upx_exclude=[],
    runtime_tmpdir=None,
    console=False,
    disable_windowed_traceback=False,
    argv_emulation=False,
    target_arch=None,
    codesign_identity=None,
    entitlements_file=None,
    icon=None,  # укажите 'icon.ico', если есть
)